//css
import 'bootstrap/dist/css/bootstrap.css';
// import { Button } from "ui";
import Landing from "./landing";

export default function Docs() {
  return (
    <div>
      <Landing />
    </div>
  );
}
